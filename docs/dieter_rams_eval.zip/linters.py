"""
linters.py — deterministic quality checks for Art Lab analysis output.

Lives next to eval.py. Imported, not run directly:

    from linters import run_linters
    findings = run_linters(analysis_text)

Each finding is a dict: {rule_id, severity, snippet, message}.
Severities: "error" (machinery leaked — hard fail, penalize heavily),
"warning" (probable problem), "info" (worth a look).

Maintenance model: when a Rams audit finds a recurring defect,
add it to the relevant list below. It then never recurs silently.
No dependencies beyond the standard library.
"""

import re

# ---------------------------------------------------------------
# TIER 0 — Machinery / scaffolding leakage (severity: error)
# Internal labels, routing variables, and prompt fragments that
# must never appear in user-facing output. Seeded from the
# 070367 Mimbres bowl Rams audit (June 2026).
# ---------------------------------------------------------------

MACHINERY_PATTERNS = [
    r"tradition_routing_basis",
    r"`[a-z_]+_basis`",                      # any backticked internal variable
    r":\s*suppressed\b",                     # "Fine art critical vocabulary: suppressed"
    r"\bcheck:\s*not triggered\b",
    r"\bnot triggered\b",
    r"\bRAP PROTOCOL active\b",              # protocol self-narration
    r"Suppressing all .{0,20}frameworks",    # displacement inventory leaking
    r"http://http://",                       # doubled protocol in ARK links
    r"\bSTEP \d+ —",                         # pipeline step headers in output
    # Add new leaks here, one line each, as audits find them.
]

# ---------------------------------------------------------------
# TIER 1a — AI slop vocabulary (severity: warning, count-based)
# Juzek & Ward (COLING 2025) 21 focal words, curated for art
# writing: "landscape", "realm", "navigate", "foster", "elevate",
# "alignment" removed — legitimate in this domain. Curate freely.
# ---------------------------------------------------------------

SLOP_WORDS = [
    "delve", "delves", "delving",
    "intricate", "commendable", "meticulous",
    "tapestry", "pivotal", "resonate", "resonates",
    "testament", "underscore", "underscores", "underscoring",
    "showcasing", "showcases",
    "compelling", "paramount", "unwavering",
]
SLOP_PER_1000_WORDS_THRESHOLD = 2.0   # flag above this density

# ---------------------------------------------------------------
# TIER 1b — Fake-humility hedging (severity: info)
# Hedges that assert while pretending not to. Real hedges with a
# named verification path ("requires pXRF") are fine and are NOT
# flagged — only the freestanding weasel forms.
# ---------------------------------------------------------------

HEDGE_PATTERNS = [
    r"\bit is worth noting that\b",
    r"\bit could be argued\b",
    r"\bone might say\b",
    r"\bperhaps suggests?\b",
    r"\bseems to (?:suggest|indicate|imply)\b",
    r"\barguably\b",
    r"\bin (?:a|some) sense\b",
]

# "not just X, but Y" contrast tic — classic LLM construction
CONTRAST_TIC = re.compile(
    r"\bnot (?:just|only|merely|simply)\b[^.]{3,80}\bbut\b", re.IGNORECASE
)

# ---------------------------------------------------------------
# TIER 2 — Length / structure assertions
# ---------------------------------------------------------------

MAX_TOTAL_WORDS = 4500          # warning above this
MAX_SECTION_WORDS = 900         # warning for any single ## section

# ---------------------------------------------------------------
# TIER 3 — Cross-section duplication (severity: warning)
# 5-gram Jaccard between ## sections, threshold 0.30 here —
# NOTE: the dedup-literature standard is 0.80 for near-identical
# documents; 0.30 catches "same points, reworded" between sections
# of one document. Calibrate on real outputs before trusting.
# The Step 5b / Pass 3 duplication scored well above this.
# ---------------------------------------------------------------

SECTION_JACCARD_THRESHOLD = 0.30
NGRAM_SIZE = 5


def _findings(rule_id, severity, snippet, message):
    return {
        "rule_id": rule_id,
        "severity": severity,
        "snippet": snippet[:120],
        "message": message,
    }


def _word_count(text):
    return len(re.findall(r"\b\w+\b", text))


def _split_sections(text):
    """Split on ## headers; returns list of (header, body)."""
    parts = re.split(r"^(##+ .+)$", text, flags=re.MULTILINE)
    sections = []
    i = 1
    while i < len(parts) - 1:
        sections.append((parts[i].strip(), parts[i + 1]))
        i += 2
    return sections


def _ngrams(text, n=NGRAM_SIZE):
    words = re.findall(r"\b\w+\b", text.lower())
    return set(tuple(words[i:i + n]) for i in range(len(words) - n + 1))


def _jaccard(a, b):
    if not a or not b:
        return 0.0
    return len(a & b) / len(a | b)


# ---------------------------------------------------------------
# Individual linters
# ---------------------------------------------------------------

def lint_machinery(text):
    out = []
    for pat in MACHINERY_PATTERNS:
        for m in re.finditer(pat, text, re.IGNORECASE):
            out.append(_findings(
                "machinery-leak", "error", m.group(0),
                f"Internal machinery leaked into output (pattern: {pat})"))
    return out


def lint_slop(text):
    total = _word_count(text)
    if total == 0:
        return []
    hits = []
    for w in SLOP_WORDS:
        hits += [w] * len(re.findall(rf"\b{w}\b", text, re.IGNORECASE))
    density = len(hits) / total * 1000
    if density > SLOP_PER_1000_WORDS_THRESHOLD:
        return [_findings(
            "slop-vocabulary", "warning", ", ".join(sorted(set(hits))),
            f"Slop density {density:.1f}/1000 words "
            f"(threshold {SLOP_PER_1000_WORDS_THRESHOLD}): {len(hits)} hits")]
    return []


def lint_hedging(text):
    out = []
    for pat in HEDGE_PATTERNS:
        for m in re.finditer(pat, text, re.IGNORECASE):
            out.append(_findings(
                "fake-hedge", "info", m.group(0),
                "Freestanding hedge — asserts while pretending not to"))
    for m in CONTRAST_TIC.finditer(text):
        out.append(_findings(
            "contrast-tic", "info", m.group(0),
            '"not just X, but Y" construction'))
    return out


def lint_length(text):
    out = []
    total = _word_count(text)
    if total > MAX_TOTAL_WORDS:
        out.append(_findings(
            "doc-length", "warning", f"{total} words",
            f"Document exceeds {MAX_TOTAL_WORDS} words"))
    for header, body in _split_sections(text):
        wc = _word_count(body)
        if wc > MAX_SECTION_WORDS:
            out.append(_findings(
                "section-length", "warning", header,
                f"Section is {wc} words (max {MAX_SECTION_WORDS})"))
    return out


def lint_duplication(text):
    """Pairwise 5-gram Jaccard between sections. Catches the
    Step 5b / Pass 3 class of bug: two sections, same content."""
    sections = _split_sections(text)
    grams = [(h, _ngrams(b)) for h, b in sections if _word_count(b) > 60]
    out = []
    for i in range(len(grams)):
        for j in range(i + 1, len(grams)):
            sim = _jaccard(grams[i][1], grams[j][1])
            if sim >= SECTION_JACCARD_THRESHOLD:
                out.append(_findings(
                    "section-duplication", "warning",
                    f"{grams[i][0]} <-> {grams[j][0]}",
                    f"Sections overlap (Jaccard {sim:.2f}) — "
                    f"likely the same content twice; check the mode prompt"))
    return out


# ---------------------------------------------------------------
# Entry point
# ---------------------------------------------------------------

ALL_LINTERS = [
    lint_machinery,
    lint_slop,
    lint_hedging,
    lint_length,
    lint_duplication,
]

# Suggested score penalties, per finding, for folding into eval.py
PENALTIES = {
    "machinery-leak": 5,
    "section-duplication": 3,
    "doc-length": 2,
    "section-length": 1,
    "slop-vocabulary": 2,
    "fake-hedge": 0.5,
    "contrast-tic": 0.5,
}


def run_linters(text):
    """Run all checks. Returns list of finding dicts."""
    findings = []
    for linter in ALL_LINTERS:
        findings.extend(linter(text))
    return findings


def score_penalty(findings):
    """Total penalty to subtract from the eval score."""
    return sum(PENALTIES.get(f["rule_id"], 0) for f in findings)


if __name__ == "__main__":
    # Manual check of a single file: python linters.py analysis.md
    import sys
    with open(sys.argv[1]) as f:
        for finding in run_linters(f.read()):
            print(f"[{finding['severity']:7}] {finding['rule_id']}: "
                  f"{finding['message']}\n          → {finding['snippet']}")
